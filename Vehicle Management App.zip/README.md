
  # Vehicle Management App

  This is a code bundle for Vehicle Management App. The original project is available at https://www.figma.com/design/Q4KyWm5bLnfjLFuDZW7rsp/Vehicle-Management-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  